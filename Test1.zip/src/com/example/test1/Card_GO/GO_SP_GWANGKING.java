package com.example.test1.Card_GO;

import com.example.gameframework.CardInterface;
//import com.exmaple.R;

public class GO_SP_GWANGKING extends CardInterface{

	
	public GO_SP_GWANGKING(){
		this.SetHp(1);
		this.SetId("card_9");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
		
	}
		

	
}