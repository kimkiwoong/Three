package com.example.test1.Card_GO;

import com.example.gameframework.CardInterface;
//import com.exmaple.R;

public class GO_NORMAL_XXX extends CardInterface{

	
	public GO_NORMAL_XXX(){
		this.SetHp(1);
		this.SetId("card_6");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
		
	}
		

	
}