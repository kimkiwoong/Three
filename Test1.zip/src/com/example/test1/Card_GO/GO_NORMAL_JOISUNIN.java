package com.example.test1.Card_GO;

import android.content.res.Resources;





import android.util.Log;

//import com.exmaple.R;



import com.example.gameframework.CardInterface;

public class GO_NORMAL_JOISUNIN extends CardInterface{


	public GO_NORMAL_JOISUNIN(){
		this.SetHp(1);
		this.SetId("card_3");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
		
	}
		

	
}