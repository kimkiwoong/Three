package com.example.test1.Card_Sin;

import com.example.gameframework.CardInterface;
//import com.exmaple.R;

public class SIN_NORMAL_POJOL2 extends CardInterface{

	
	public SIN_NORMAL_POJOL2(){
		this.SetHp(1);
		this.SetId("card_11");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
	}
		

	
}