package com.example.test1.Card_Sin;

import com.example.gameframework.CardInterface;
//import com.exmaple.R;

public class SIN_SP_KIMYOUSIN extends CardInterface{

	
	public SIN_SP_KIMYOUSIN(){
		this.SetHp(1);
		this.SetId("card_19");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
	}
		

	
}