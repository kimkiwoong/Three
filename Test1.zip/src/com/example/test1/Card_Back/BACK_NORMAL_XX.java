package com.example.test1.Card_Back;

import android.content.res.Resources;





import android.util.Log;

//import com.exmaple.R;



import com.example.gameframework.CardInterface;

public class BACK_NORMAL_XX extends CardInterface{

	
	public BACK_NORMAL_XX(){
		this.SetHp(1);
		this.SetId("card_24");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
	}
		

	
}