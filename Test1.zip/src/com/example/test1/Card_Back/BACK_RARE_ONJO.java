package com.example.test1.Card_Back;

import android.content.res.Resources;





import android.util.Log;

//import com.exmaple.R;



import com.example.gameframework.CardInterface;

public class BACK_RARE_ONJO extends CardInterface {

	
	public BACK_RARE_ONJO(){
		this.SetHp(1);
		this.SetId("card_26");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
		
	}
		

	
}