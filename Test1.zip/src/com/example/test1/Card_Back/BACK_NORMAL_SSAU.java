package com.example.test1.Card_Back;

import android.content.res.Resources;





import android.util.Log;

//import com.exmaple.R;



import com.example.gameframework.CardInterface;

public class BACK_NORMAL_SSAU extends CardInterface{

	
	public BACK_NORMAL_SSAU(){
		this.SetHp(1);
		this.SetId("card_23");
		this.SetmPower(1);
		this.SetNara(0);
		this.SetMagic(true);
		this.SetCState(0);
		this.SetMagicName(null);
	}
		

	
}